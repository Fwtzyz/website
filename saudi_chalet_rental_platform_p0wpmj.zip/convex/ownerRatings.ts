// Temporarily disabled
export const placeholder = "owner rating functions disabled";

// This file has been moved to authSessions.ts

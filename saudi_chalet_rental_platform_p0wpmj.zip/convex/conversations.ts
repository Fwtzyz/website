// Temporarily disabled - will be implemented later
export const placeholder = "conversations functionality disabled";

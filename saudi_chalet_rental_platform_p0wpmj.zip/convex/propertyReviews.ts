// Temporarily disabled
export const placeholder = "property review functions disabled";

// Temporarily disabled - will be implemented later
export const placeholder = "messages functionality disabled";

export function RatableBookings() {
  // Rating system temporarily disabled
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-bold mb-4">الحجوزات القابلة للتقييم</h2>
      <p className="text-gray-500">نظام التقييم غير متوفر حالياً</p>
    </div>
  );
}
